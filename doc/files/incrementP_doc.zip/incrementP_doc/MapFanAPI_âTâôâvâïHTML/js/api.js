$(function(){

	// メニュークリック時の処理
	$(".menuList").children().click(function() {
		$(":header .title").text($(this).text());
		var titleText = $(this).text();
		var titleParseText = titleText.split('.');
		var titleNo = parseInt(titleParseText[0])-1;
		$("#explain_summary").html(demoText[titleNo].sum);
		$("#explain_detail").html(
			datailHeader +demoText[titleNo].detail +srcHeader +demoText[titleNo].src +srcFooter);
		$("#map_iframe").attr("src",demoText[titleNo].url);
	});

	// 初期表示
	$(":header .title").text(demoText[0].title);
	$("#explain_summary").html(demoText[0].sum);
	$("#explain_detail").html(
		datailHeader +demoText[0].detail +srcHeader +demoText[0].src +srcFooter);
	$("#map_iframe").attr("src","");
	$("#map_iframe").attr("src",demoText[0].url);

});